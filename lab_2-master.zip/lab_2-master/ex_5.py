from time import sleep
from librip.ctxmngrs import timer

with timer():
    sleep(5.5)
